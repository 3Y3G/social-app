"use client"

import { useState, useEffect } from "react"
import type { StoryWithAuthor } from "@/lib/types"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { Plus } from "lucide-react"
import { useSession } from "next-auth/react"
import Link from "next/link"

export default function Stories() {
  const { data: session } = useSession()
  const [stories, setStories] = useState<StoryWithAuthor[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchStories() {
      try {
        const response = await fetch("/api/stories")
        const data = await response.json()
        if (data.success) {
          setStories(data.data)
        } else {
          setError(data.error || "Failed to fetch stories")
        }
      } catch (error) {
        setError("An error occurred while fetching stories")
      } finally {
        setLoading(false)
      }
    }

    fetchStories()
  }, [])

  if (loading) return <div>Loading stories...</div>
  if (error) return <div>Error: {error}</div>

  return (
    <Card className="p-4">
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex w-max space-x-4">
          {session?.user && (
            <Button variant="ghost" className="flex flex-col items-center space-y-1 p-0">
              <Avatar className="h-16 w-16 ring-2 ring-blue-500">
                <div className="absolute bottom-0 right-0 rounded-full bg-blue-500 p-1">
                  <Plus className="h-4 w-4 text-white" />
                </div>
                <AvatarImage src={session.user.image || undefined} alt={session.user.name || ""} />
                <AvatarFallback>{session.user.name?.[0]}</AvatarFallback>
              </Avatar>
              <span className="text-xs">Your Story</span>
            </Button>
          )}
          {!session && (
            <Link href="/login">
              <Button variant="ghost" className="flex flex-col items-center space-y-1 p-0">
                <Avatar className="h-16 w-16 ring-2 ring-blue-500">
                  <div className="absolute bottom-0 right-0 rounded-full bg-blue-500 p-1">
                    <Plus className="h-4 w-4 text-white" />
                  </div>
                  <AvatarFallback>+</AvatarFallback>
                </Avatar>
                <span className="text-xs">Add Story</span>
              </Button>
            </Link>
          )}
          {stories.map((story) => (
            <Button key={story.id} variant="ghost" className="flex flex-col items-center space-y-1 p-0">
              <Avatar className="h-16 w-16 ring-2 ring-blue-500">
                <AvatarImage src={story.author.image || undefined} alt={story.author.name || ""} />
                <AvatarFallback>{story.author.name?.[0]}</AvatarFallback>
              </Avatar>
              <span className="text-xs">{story.author.name}</span>
            </Button>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </Card>
  )
}

