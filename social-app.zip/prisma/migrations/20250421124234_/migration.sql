/*
  Warnings:

  - You are about to drop the column `type` on the `SavedItem` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "SavedItem" DROP COLUMN "type";
