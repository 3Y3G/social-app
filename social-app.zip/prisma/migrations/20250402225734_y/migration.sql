-- AlterTable
ALTER TABLE "Notification" ADD COLUMN     "conversationId" TEXT;
