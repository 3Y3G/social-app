"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import type { PostWithAuthor } from "@/lib/types"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  Heart,
  MessageCircle,
  Share2,
  MoreHorizontal,
  Bookmark,
  Trash2,
  Pencil,
} from "lucide-react"
import { formatDate } from "@/lib/utils"
import { toggleLike, deletePost } from "@/lib/post-actions"
import { useSession } from "next-auth/react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useToast } from "@/hooks/use-toast"

/* -------------------------------------------------------------------------- */
/* PostWithAuthor now includes media array                                    */
/* -------------------------------------------------------------------------- */
/* type PostWithAuthor = Prisma.Post & {
     author: { … }
     _count: { likes: number; comments: number }
     media: { url: string; type: "IMAGE" | "VIDEO"; }[]
   }                                                                          */

export default function Feed() {
  const [posts, setPosts] = useState<PostWithAuthor[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set())

  const { data: session } = useSession()
  const router = useRouter()
  const searchParams = useSearchParams()
  const feedType = searchParams.get("feed") || "latest"
  const { toast } = useToast()

  /* ---------------------------------------------------------------------- */
  /* helpers                                                                */
  /* ---------------------------------------------------------------------- */

  function openPost(id: string) {
    router.push(`/posts/${id}`)
  }

  /* ---------------------------------------------------------------------- */
  /* effects                                                                */
  /* ---------------------------------------------------------------------- */

  useEffect(() => {
    setPosts([])
    setPage(1)
    setHasMore(true)
    setLoading(true)
    fetchPosts(1)
  }, [feedType])

  useEffect(() => {
    if (page > 1) fetchPosts(page)
  }, [page])

  useEffect(() => {
    if (!session?.user) return

    posts.forEach(async post => {
      try {
        const res = await fetch(`/api/posts/${post.id}/like`)
        const data = await res.json()
        if (data.success && data.data.liked) {
          setLikedPosts(prev => new Set([...prev, post.id]))
        }
      } catch (err) {
        console.error("Like check error:", err)
      }
    })
  }, [posts, session])

  /* ---------------------------------------------------------------------- */
  /* data fetch                                                             */
  /* ---------------------------------------------------------------------- */

  async function fetchPosts(pageNum: number) {
    try {
      setLoading(true)
      let apiUrl = `/api/posts?page=${pageNum}&limit=5`
      if (feedType === "popular") apiUrl += "&sort=popular"
      if (feedType === "for-you") apiUrl += "&personalized=true"

      const res = await fetch(apiUrl)
      const data = await res.json()

      if (data.success) {
        setPosts(prev => (pageNum === 1 ? data.data : [...prev, ...data.data]))
        setHasMore(data.meta.page < data.meta.pages)
      } else {
        setError(data.error || "Неуспешно зареждане на публикации")
      }
    } catch {
      setError("Възникна грешка при зареждане на публикациите")
    } finally {
      setLoading(false)
    }
  }

  /* ---------------------------------------------------------------------- */
  /* actions                                                                */
  /* ---------------------------------------------------------------------- */

  async function handleLike(postId: string) {
    if (!session) return router.push("/login")

    try {
      const result = await toggleLike(postId)
      if (!result.success) return

      setLikedPosts(prev => {
        const next = new Set([...prev])
        result.data?.liked ? next.add(postId) : next.delete(postId)
        return next
      })

      setPosts(posts.map(p =>
        p.id === postId
          ? { ...p, _count: { ...p._count, likes: p._count.likes + (result.data?.liked ? 1 : -1) } }
          : p,
      ))
    } catch (err) {
      console.error("Грешка при харесване:", err)
    }
  }

  async function handleSavePost(postId: string) {
    if (!session) return router.push("/login")

    try {
      const res = await fetch("/api/saved", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "POST", postId }),
      })
      const data = await res.json()

      toast({
        title: data.success ? "Успешно" : "Грешка",
        description: data.success ? "Публикацията е запазена" : data.error,
        variant: data.success ? "default" : "destructive",
      })
    } catch {
      toast({
        title: "Грешка",
        description: "Възникна проблем при запазване на публикацията",
        variant: "destructive",
      })
    }
  }

  async function handleDeletePost(id: string) {
    if (!session) return

    try {
      const result = await deletePost(id)
      toast({
        title: result.success ? "Успешно" : "Грешка",
        description: result.success ? "Постът е изтрит" : result.error,
        variant: result.success ? "default" : "destructive",
      })
      if (result.success) setPosts(prev => prev.filter(p => p.id !== id))
    } catch {
      toast({
        title: "Грешка",
        description: "Грешка при изтриване",
        variant: "destructive",
      })
    }
  }

  function loadMore() {
    if (!loading && hasMore) setPage(prev => prev + 1)
  }

  /* ---------------------------------------------------------------------- */
  /* UI guards                                                              */
  /* ---------------------------------------------------------------------- */

  if (loading && posts.length === 0)
    return <div className="py-8 text-center">Зареждане на публикации...</div>

  if (error && posts.length === 0)
    return <div className="py-8 text-center text-red-500">Грешка: {error}</div>

  if (posts.length === 0)
    return <div className="py-8 text-center">Няма публикации.</div>

  /* ---------------------------------------------------------------------- */
  /* component                                                              */
  /* ---------------------------------------------------------------------- */

  return (
    <div className="space-y-4">
      {posts.map(post => {
        const firstMedia = post.PostMedia[0] || null

        return (
          <Card key={post.id} className="cursor-pointer" onClick={() => openPost(post.id)}>
            <CardContent className="pt-6" onClick={() => openPost(post.id)}>
              {/* header */}
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <Link href={`/profile/${post.author.id}`} onClick={e => e.stopPropagation()}>
                    <Avatar>
                      <AvatarImage src={post.author.image || undefined} alt={post.author.name || ""} />
                      <AvatarFallback>{post.author.name?.[0]}</AvatarFallback>
                    </Avatar>
                  </Link>
                  <div>
                    <Link
                      href={`/profile/${post.author.id}`}
                      className="font-semibold hover:underline"
                      onClick={e => e.stopPropagation()}
                    >
                      {post.author.name}
                    </Link>
                    <p className="text-sm text-gray-500">{formatDate(post.createdAt)}</p>
                  </div>
                </div>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleSavePost(post.id)}>
                      Запази публикацията
                    </DropdownMenuItem>

                    {session?.user?.id === post.author.id && (
                      <>
                        <DropdownMenuItem asChild>
                          <Link href={`/posts/${post.id}/edit`}>
                            <Pencil className="mr-2 h-4 w-4" />
                            Редактирай
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={e => {
                            e.stopPropagation()
                            handleDeletePost(post.id)
                          }}
                          className="text-red-500"
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Изтрий
                        </DropdownMenuItem>
                      </>
                    )}

                    <DropdownMenuItem>Докладвай</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* body */}
              <div className="mt-2 space-y-2">
                {post.content && <p>{post.content}</p>}

                {firstMedia &&
                  (firstMedia.type === "IMAGE" ? (
                    <img
                      src={firstMedia.url}
                      alt="Медия към публикацията"
                      className="max-h-96 w-full rounded-lg object-cover"
                      onClick={() => openPost(post.id)}
                    />
                  ) : (
                    <video
                      src={firstMedia.url}
                      controls
                      className="max-h-96 w-full rounded-lg"
                      onClick={e => e.stopPropagation()}
                    />
                  ))}
              </div>

              {/* actions */}
              <div className="mt-4 flex items-center justify-between">
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className={likedPosts.has(post.id) ? "text-red-500" : ""}
                    onClick={e => {
                      e.stopPropagation()
                      handleLike(post.id)
                    }}
                  >
                    <Heart className={`mr-1 h-4 w-4 ${likedPosts.has(post.id) ? "fill-current" : ""}`} />
                    {post._count.likes}
                  </Button>

                  <Button variant="ghost" size="sm" asChild>
                    <Link href={`/posts/${post.id}`} onClick={e => e.stopPropagation()}>
                      <MessageCircle className="mr-1 h-4 w-4" />
                      {post._count.comments}
                    </Link>
                  </Button>
                </div>

                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={e => {
                      e.stopPropagation()
                      handleSavePost(post.id)
                    }}
                  >
                    <Bookmark className="mr-1 h-4 w-4" />
                    Запази
                  </Button>

                  <Button variant="ghost" size="sm" onClick={e => e.stopPropagation()}>
                    <Share2 className="mr-1 h-4 w-4" />
                    Сподели
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )
      })}

      {hasMore && (
        <div className="py-4 text-center">
          <Button onClick={loadMore} disabled={loading}>
            {loading ? "Зареждане..." : "Зареди още"}
          </Button>
        </div>
      )}
    </div>
  )
}
