"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Heart,
  Share2,
  MoreHorizontal,
  Bookmark,
  Trash2,
  Pencil,
  MessageCircle,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { formatDate } from "@/lib/utils"
import { toggleLike, deletePost } from "@/lib/post-actions"
import { useSession } from "next-auth/react"
import { useToast } from "@/hooks/use-toast"
import type { PostWithAuthor } from "@/lib/types"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useMobile } from "@/hooks/use-mobile"

export default function PostDetail({ postId }: { postId: string }) {
  const [post, setPost] = useState<PostWithAuthor | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isLiked, setIsLiked] = useState(false)

  const { data: session } = useSession()
  const router = useRouter()
  const { toast } = useToast()
  const isMobileHook = useMobile()

  /* ---------------------------------------------------------------------- */
  /* load post & like status                                                */
  /* ---------------------------------------------------------------------- */

  useEffect(() => {
    load()
  }, [postId])

  useEffect(() => {
    if (session?.user && post) likeStatus()
  }, [post, session])

  async function load() {
    try {
      setLoading(true)
      const res = await fetch(`/api/posts/${postId}`)
      const data = await res.json()
      console.log(data)
      if (data.success) setPost(data.data)
      else setError(data.error || "Failed to fetch post")
    } catch {
      setError("An error occurred while fetching the post")
    } finally {
      setLoading(false)
    }
  }

  async function likeStatus() {
    try {
      const res = await fetch(`/api/posts/${postId}/like`)
      
      const data = await res.json()
      
      if (data.success) setIsLiked(data.data.liked)
    } catch (err) {
      console.error("Like status error:", err)
    }
  }

  /* ---------------------------------------------------------------------- */
  /* user actions                                                           */
  /* ---------------------------------------------------------------------- */

  async function handleLike() {
    if (!session) return router.push("/login")

    try {
      const result = await toggleLike(postId)
      if (!result.success || !result.data) return

      setIsLiked(result.data.liked)
      if (post) {
        setPost({
          ...post,
          _count: {
            ...post._count,
            likes: result.data.liked
              ? post._count.likes + 1
              : post._count.likes - 1,
          },
        })
      }
    } catch {
      toast({
        title: "Error",
        description: "Failed to like post",
        variant: "destructive",
      })
    }
  }

  async function handleSavePost() {
    if (!session) return router.push("/login")

    try {
      const res = await fetch("/api/saved", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "POST", postId }),
      })
      const data = await res.json()

      toast({
        title: data.success ? "Success" : "Error",
        description: data.success ? "Post saved" : data.error,
        variant: data.success ? "default" : "destructive",
      })
    } catch {
      toast({
        title: "Error",
        description: "Save failed",
        variant: "destructive",
      })
    }
  }

  async function handleDelete() {
    if (!session || !post) return

    try {
      const result = await deletePost(postId)
      toast({
        title: result.success ? "Success" : "Error",
        description: result.success ? "Post deleted" : result.error,
        variant: result.success ? "default" : "destructive",
      })
      if (result.success) router.push("/")
    } catch {
      toast({
        title: "Error",
        description: "Delete failed",
        variant: "destructive",
      })
    }
  }

  /* ---------------------------------------------------------------------- */
  /* guards                                                                  */
  /* ---------------------------------------------------------------------- */

  if (loading)
    return (
      <div className="flex items-center justify-center py-8">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-gray-900" />
      </div>
    )

  if (error)
    return (
      <div className="py-8 px-4 text-center">
        <div className="rounded-lg bg-red-50 p-4 text-red-500">Error: {error}</div>
      </div>
    )

  if (!post)
    return (
      <div className="py-8 px-4 text-center">
        <div className="rounded-lg bg-gray-50 p-4">Post not found</div>
      </div>
    )
  console.log(post)
  const firstMedia = post.PostMedia[0] || null
  const isOwner = session?.user?.id === post.author.id
  const isAdmin = session?.user?.role === "ADMIN"

  /* ---------------------------------------------------------------------- */
  /* render                                                                  */
  /* ---------------------------------------------------------------------- */

  return (
    <Card className="rounded-none border-0 shadow-none md:rounded-lg md:border md:shadow">
      <CardContent className="p-3 sm:p-6">
        {/* header */}
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3">
            <Link href={`/profile/${post.author.id}`}>
              <Avatar className="h-10 w-10">
                <AvatarImage src={post.author.image || undefined} alt={post.author.name || ""} />
                <AvatarFallback>{post.author.name?.[0]}</AvatarFallback>
              </Avatar>
            </Link>
            <div>
              <Link href={`/profile/${post.author.id}`} className="font-semibold hover:underline">
                {post.author.name}
              </Link>
              <p className="text-xs text-gray-500">{formatDate(post.createdAt)}</p>
            </div>
          </div>

          {/* actions – mobile uses Sheet, desktop uses Dropdown */}
          <PostActions
            isMobile={isMobileHook}
            ownerOrAdmin={isOwner || isAdmin}
            onSave={handleSavePost}
            onDelete={handleDelete}
            postId={post.id}
          />
        </div>

        {/* body */}
        <div className="mt-4 space-y-3">
          {post.content && <p className="whitespace-pre-wrap">{post.content}</p>}

          {firstMedia &&
            (firstMedia.type === "IMAGE" ? (
              <img
                src={firstMedia.url}
                alt="Post media"
                className="max-h-[80vh] w-full rounded-lg object-cover"
              />
            ) : (
              <video
                src={firstMedia.url}
                controls
                className="max-h-[80vh] w-full rounded-lg"
              />
            ))}
        </div>

        {/* footer / actions */}
        <div className="mt-4 flex items-center justify-between border-t pt-2">
          <div className="flex space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              className={isLiked ? "text-red-500" : ""}
            >
              <Heart className={`mr-1.5 h-5 w-5 ${isLiked ? "fill-current" : ""}`} />
              {post._count.likes}
            </Button>

            <Button variant="ghost" size="sm" asChild>
              <Link href={`/posts/${post.id}#comments`}>
                <MessageCircle className="mr-1.5 h-5 w-5" />
                {post._count.comments}
              </Link>
            </Button>
          </div>

          <div className="hidden md:flex space-x-2">
            <Button variant="ghost" size="sm" onClick={handleSavePost}>
              <Bookmark className="mr-1 h-4 w-4" />
              Save
            </Button>
            <Button variant="ghost" size="sm">
              <Share2 className="mr-1 h-4 w-4" />
              Share
            </Button>
          </div>

          <div className="md:hidden">
            <Button variant="ghost" size="sm">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

/* -------------------------------------------------------------------------- */
/* helper component for action menus                                          */
/* -------------------------------------------------------------------------- */

function PostActions({
  isMobile,
  ownerOrAdmin,
  onSave,
  onDelete,
  postId,
}: {
  isMobile: boolean
  ownerOrAdmin: boolean
  onSave: () => void
  onDelete: () => void
  postId: string
}) {
  if (isMobile) {
    return (
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="sm" className="rounded-full">
            <MoreHorizontal className="h-5 w-5" />
          </Button>
        </SheetTrigger>

        <SheetContent side="bottom" className="rounded-t-xl">
          <div className="space-y-4 py-4">
            <h3 className="pb-4 text-center text-lg font-semibold">Post options</h3>

            <Button variant="ghost" className="h-12 w-full justify-start" onClick={onSave}>
              <Bookmark className="mr-3 h-5 w-5" />
              Save Post
            </Button>

            {ownerOrAdmin && (
              <>
                <Button variant="ghost" className="h-12 w-full justify-start" asChild>
                  <Link href={`/posts/${postId}/edit`}>
                    <Pencil className="mr-3 h-5 w-5" />
                    Edit Post
                  </Link>
                </Button>

                <Button
                  variant="ghost"
                  className="h-12 w-full justify-start text-red-500"
                  onClick={onDelete}
                >
                  <Trash2 className="mr-3 h-5 w-5" />
                  Delete Post
                </Button>
              </>
            )}

            <Button variant="ghost" className="h-12 w-full justify-start">
              <Share2 className="mr-3 h-5 w-5" />
              Share Post
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    )
  }

  /* desktop dropdown */
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={onSave}>
          <Bookmark className="mr-2 h-4 w-4" />
          Save Post
        </DropdownMenuItem>

        {ownerOrAdmin && (
          <>
            <DropdownMenuItem asChild>
              <Link href={`/posts/${postId}/edit`}>
                <Pencil className="mr-2 h-4 w-4" />
                Edit Post
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onDelete} className="text-red-500">
              <Trash2 className="mr-2 h-4 w-4" />
              Delete Post
            </DropdownMenuItem>
          </>
        )}

        <DropdownMenuItem>Report</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
