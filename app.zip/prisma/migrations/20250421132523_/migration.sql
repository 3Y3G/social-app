-- AlterTable
ALTER TABLE "Story" ADD COLUMN     "caption" TEXT;
