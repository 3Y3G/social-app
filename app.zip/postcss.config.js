module.exports = {
  plugins: {
    tailwindcss: {},
  },
}

